﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace FluffyHope
{
    public partial class VolunteerForm : Window
    {
        public VolunteerForm()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string fullName = txtFullName.Text;
            string city = txtCity.Text;
            string phoneNumber = txtPhoneNumber.Text;
            string email = txtEmail.Text;
            string reason = txtReason.Text;

            string connectionString = "Data Source=MSI;Initial Catalog=FluffyHopeDB;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO Volenteer (FullName, City, PhoneNumber, Email, Reason) VALUES (@FullName, @City, @PhoneNumber, @Email, @Reason)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FullName", fullName);
                        command.Parameters.AddWithValue("@City", city);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Reason", reason);

                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Мы вас записали в Волонтеров, Спасибо! Скоро с вами свяжемся.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                    txtFullName.Text = "";
                    txtCity.Text = "";
                    txtPhoneNumber.Text = "";
                    txtEmail.Text = "";
                    txtReason.Text = "";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при сохранении данных: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpAnimals mainWindow = new HelpAnimals();
            mainWindow.Show();
            Hide();
        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {
            Donate mainWindow = new Donate();
            mainWindow.Show();
            Hide();
        }
    }
}