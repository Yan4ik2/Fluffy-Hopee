﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FluffyHope
{

    public partial class LostAndFound : Window
    {
        public ObservableCollection<LostAndFoundItem> LostAndFoundItems { get; set; } = new ObservableCollection<LostAndFoundItem>();

        public LostAndFound()
        {
            InitializeComponent();
            LoadDataFromDatabase();  
            LostAndFoundItemsControl.ItemsSource = LostAndFoundItems; 

            DataContext = this; // 
        }

        private void LoadDataFromDatabase()
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["FluffyHopeDB"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT AnimalType, City, Description, ContactName, ContactPhone, ContactEmail, ImageURL, DatePosted, PostType FROM dbo.LostAndFound";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            LostAndFoundItem item = new LostAndFoundItem
                            {
                                AnimalType = reader["AnimalType"].ToString(),
                                City = reader["City"].ToString(),
                                Description = reader["Description"].ToString(),
                                ContactName = reader["ContactName"].ToString(),
                                ContactPhone = reader["ContactPhone"].ToString(),
                                ContactEmail = reader["ContactEmail"].ToString(),
                                ImagePath = reader["ImageURL"].ToString(),  
                                DatePosted = Convert.ToDateTime(reader["DatePosted"]),  
                                PostType = reader["PostType"].ToString()
                            };

                            LostAndFoundItems.Add(item);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpAnimals mainWindow = new HelpAnimals();
            mainWindow.Show();
            Hide();
        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {
            Donate mainWindow = new Donate();
            mainWindow.Show();
            Hide();
        }

        public class LostAndFoundItem
        {
            public string AnimalType { get; set; }
            public string City { get; set; }
            public string Description { get; set; }
            public string ContactName { get; set; }
            public string ContactPhone { get; set; }
            public string ContactEmail { get; set; }
            public string ImagePath { get; set; } 
            public DateTime DatePosted { get; set; }
            public string PostType { get; set; }

            public string Name { get => AnimalType; }
            public DateTime DateLostFound { get => DatePosted; }
            public string Location { get => City; }
        }
    }
}