﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace FluffyHope
{
    public partial class AnimalShelter : Window
    {
        private string connectionString = "Data Source=MSI;Initial Catalog=FluffyHopeDB;Integrated Security=True;";
        private List<Animal> allAnimals = new List<Animal>();

        public AnimalShelter()
        {
            InitializeComponent();
        }

        private void AnimalShelter_Loaded(object sender, RoutedEventArgs e)
        {
            LoadAnimals();
            LoadTypeFilter();
            LoadAgeFilter();
        }

        private void LoadAnimals()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = @"
                        SELECT AnimalID, Name, Type, Poroda, Age, ImageURL, Description,
                               (SELECT TOP 1 Address FROM dbo.Shelters WHERE ShelterID = dbo.Animals.ShelterID) AS City
                        FROM dbo.Animals";

                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();
                    allAnimals.Clear();
                    while (reader.Read())
                    {
                        Animal animal = new Animal
                        {
                            AnimalID = Convert.ToInt32(reader["AnimalID"]),
                            Name = reader["Name"]?.ToString(),
                            Type = reader["Type"].ToString(),
                            Poroda = reader["Poroda"]?.ToString(),
                            ImageURL = reader["ImageURL"].ToString(),
                            Description = reader["Description"].ToString(),
                            Age = Convert.ToInt32(reader["Age"]),
                            City = reader["City"]?.ToString()
                        };
                        allAnimals.Add(animal);
                    }
                    reader.Close();
                }

                AnimalListView.ItemsSource = allAnimals;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки животных: " + ex.Message);
            }
        }

        private void LoadTypeFilter()
        {
            List<string> types = new List<string> { "Все" };
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT DISTINCT Type FROM dbo.Animals";
                    SqlCommand command = new SqlCommand(query, connection);
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        types.Add(reader["Type"].ToString());
                    }
                    reader.Close();
                }

                TypeComboBox.ItemsSource = types;
                TypeComboBox.SelectedItem = "Все";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки типов: " + ex.Message);
            }
        }

        private void LoadAgeFilter()
        {
            List<string> ages = new List<string> { "Все", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10+" };
            AgeComboBox.ItemsSource = ages;
            AgeComboBox.SelectedItem = "Все";
        }

        private void TypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void AgeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            string selectedType = TypeComboBox.SelectedItem?.ToString();
            string selectedAge = AgeComboBox.SelectedItem?.ToString();

            IEnumerable<Animal> filteredAnimals = allAnimals;

            if (selectedType != "Все")
            {
                filteredAnimals = filteredAnimals.Where(a => a.Type == selectedType);
            }

            if (selectedAge != "Все")
            {
                if (selectedAge == "10+")
                {
                    filteredAnimals = filteredAnimals.Where(a => a.Age >= 10);
                }
                else
                {
                    if (int.TryParse(selectedAge, out int ageValue))
                    {
                        filteredAnimals = filteredAnimals.Where(a => a.Age == ageValue);
                    }
                }
            }

            AnimalListView.ItemsSource = filteredAnimals;
        }

        private void Adopt_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is int animalID)
            {
                MessageBox.Show($"Вы хотите забрать животное с ID: {animalID}.");
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpAnimals mainWindow = new HelpAnimals();
            mainWindow.Show();
            Hide();
        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {
            Donate mainWindow = new Donate();
            mainWindow.Show();
            Hide();
        }
    }

    public class Animal
    {
        public int AnimalID { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Poroda { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string ImageURL { get; set; }
        public string Description { get; set; }
    }
}