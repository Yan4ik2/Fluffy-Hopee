﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FluffyHope
{
    public partial class HelpAnimals : Window
    {
        public HelpAnimals()
        {
            InitializeComponent();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {

        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {
            Donate mainWindow = new Donate();
            mainWindow.Show();
            Hide();
        }
        private void Volonteer(object sender, RoutedEventArgs e)
        {
            VolunteerForm mainWindow = new VolunteerForm();
            mainWindow.Show();
            Hide();
        }
        private void Donates(object sender, RoutedEventArgs e)
        {
            Donations mainWindow = new Donations();
            mainWindow.Show();
            Hide();
        }
        private void LostFilm(object sender, RoutedEventArgs e)
        {
            LostAndFound mainWindow = new LostAndFound();
            mainWindow.Show();
            Hide();
        }
        private void Stat(object sender, RoutedEventArgs e)
        {
            Statistic mainWindow = new Statistic();
            mainWindow.Show();
            Hide();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void Shelter(object sender, RoutedEventArgs e)
        {
            AnimalShelter mainWindow = new AnimalShelter();
            mainWindow.Show();
            Hide();
        }
    }
}
