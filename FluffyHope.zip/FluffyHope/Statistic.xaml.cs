﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FluffyHope
{
    public partial class Statistic : Window
    {
        public Statistic()
        {
            InitializeComponent();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpAnimals mainWindow = new HelpAnimals();
            mainWindow.Show();
            Hide();
        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {
            Donate mainWindow = new Donate();
            mainWindow.Show();
            Hide();
        }
    }
}
