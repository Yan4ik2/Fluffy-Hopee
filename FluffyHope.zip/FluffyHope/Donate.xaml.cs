﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace FluffyHope
{

    public partial class Donate : Window
    {
        private string connectionString = "Data Source=MSI;Initial Catalog=FluffyHopeDB;Integrated Security=True;";
        public Donate()
        {
            InitializeComponent();
        }
        private void Donate_Button(object sender, RoutedEventArgs e)
        {
            bool hasEmpty = false;

            PRICE.ClearValue(BorderBrushProperty);
            CardNumberTextBox.ClearValue(BorderBrushProperty);
            ExpiryDateTextBox.ClearValue(BorderBrushProperty);
            CVCPasswordBox.ClearValue(BorderBrushProperty);
            EmailTextBox.ClearValue(BorderBrushProperty);

            if (string.IsNullOrWhiteSpace(PRICE.Text))
            {
                PRICE.BorderBrush = Brushes.Red;
                hasEmpty = true;
            }
            if (string.IsNullOrWhiteSpace(CardNumberTextBox.Text))
            {
                CardNumberTextBox.BorderBrush = Brushes.Red;
                hasEmpty = true;
            }
            if (string.IsNullOrWhiteSpace(ExpiryDateTextBox.Text))
            {
                ExpiryDateTextBox.BorderBrush = Brushes.Red;
                hasEmpty = true;
            }
            if (string.IsNullOrWhiteSpace(CVCPasswordBox.Password))
            {
                CVCPasswordBox.BorderBrush = Brushes.Red;
                hasEmpty = true;
            }
            if (string.IsNullOrWhiteSpace(EmailTextBox.Text) || !IsValidEmail(EmailTextBox.Text))
            {
                EmailTextBox.BorderBrush = Brushes.Red;
                hasEmpty = true;
            }

            if (hasEmpty)
            {
                MessageBox.Show("Пожалуйста, заполните все поля.");
                return;
            }

            MessageBox.Show("Спасибо за поддержку!");

            try
            {
                Donation newDonation = new Donation
                {
                    Price = decimal.Parse(PRICE.Text),
                    CardNumber = CardNumberTextBox.Text,
                    Expiry = ExpiryDateTextBox.Text,
                    CVC = CVCPasswordBox.Password,
                    Email = EmailTextBox.Text
                };

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "INSERT INTO Donations (Price, CardNumber, Expiry, CVC, Email) " +
                                   "VALUES (@Price, @CardNumber, @Expiry, @CVC, @Email)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Price", newDonation.Price);
                        command.Parameters.AddWithValue("@CardNumber", newDonation.CardNumber);
                        command.Parameters.AddWithValue("@Expiry", newDonation.Expiry);
                        command.Parameters.AddWithValue("@CVC", newDonation.CVC);
                        command.Parameters.AddWithValue("@Email", newDonation.Email);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Пожертвование успешно добавлено!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении пожертвования: " + ex.Message);
            }
        }

        private void OnlyDigits_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(char.IsDigit);
        }

        private void OnlyDigitsAndSlash_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !e.Text.All(c => char.IsDigit(c) || c == '/');
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                return System.Text.RegularExpressions.Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }
            catch
            {
                return false;
            }
        }




        private void Home_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Hide();
        }

        private void AboutUs_Click(object sender, RoutedEventArgs e)
        {
            AboutUs mainWindow = new AboutUs();
            mainWindow.Show();
            Hide();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            HelpAnimals mainWindow = new HelpAnimals();
            mainWindow.Show();
            Hide();
        }

        private void HowHelp_Click(object sender, RoutedEventArgs e)
        {
            HowToHelp mainWindow = new HowToHelp();
            mainWindow.Show();
            Hide();
        }

        private void Contact_Click(object sender, RoutedEventArgs e)
        {
            Contacts mainWindow = new Contacts();
            mainWindow.Show();
            Hide();
        }

        private void Donat_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CardNumberTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0))
            {
                e.Handled = true;
                return;
            }

            var tb = (TextBox)sender;

            string text = tb.Text.Remove(tb.SelectionStart, tb.SelectionLength);
            text = text.Insert(tb.SelectionStart, e.Text);
            text = text.Replace(" ", "");

            if (text.Length > 16)
            {
                e.Handled = true;
                return;
            }

            tb.Text = string.Join(" ", Enumerable.Range(0, text.Length / 4 + 1)
                .Select(i => text.Skip(i * 4).Take(4))
                .Where(g => g.Any())
                .Select(g => new string(g.ToArray())));

            tb.CaretIndex = tb.Text.Length;
            e.Handled = true;
        }

        private void CardNumber(object sender, TextChangedEventArgs e)
        {

        }

        private void PRICE_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void CVCPasswordBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, 0) || CVCPasswordBox.Password.Length >= 3)
                e.Handled = true;
        }

        private void ExpiryDateTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !char.IsDigit(e.Text, 0);

            if (!e.Handled)
            {
                var tb = (TextBox)sender;
                string text = tb.Text;

                if (tb.SelectionLength > 0)
                    text = text.Remove(tb.SelectionStart, tb.SelectionLength);

                text = text.Insert(tb.SelectionStart, e.Text);

                if (text.Length == 2 && !text.Contains("/"))
                {
                    tb.Text = text + "/";
                    tb.CaretIndex = tb.Text.Length;
                    e.Handled = true;
                }

                if (text.Length > 5) e.Handled = true;
            }
        }

        private void Expiry(object sender, TextChangedEventArgs e)
        {

        }

        private void Email(object sender, TextChangedEventArgs e)
        {

        }



    }
    public class Donation
    {
        public decimal Price { get; set; }
        public string CardNumber { get; set; }
        public string Expiry { get; set; }
        public string CVC { get; set; }
        public string Email { get; set; }
    }

}